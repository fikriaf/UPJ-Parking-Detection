# Dataset Parkiran UPJ > 2025-11-10 9:46pm
https://universe.roboflow.com/fikri-uuphx/dataset-parkiran-upj-ljoum

Provided by a Roboflow user
License: CC BY 4.0

